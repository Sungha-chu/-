﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace TestLog.Models
{
    public partial class TestLogContext : DbContext
    {
        public TestLogContext()
        {
        }

        public TestLogContext(DbContextOptions<TestLogContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LogItem> LogItems { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LogItem>(entity =>
            {
                entity.ToTable("LogItem");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.LogMsg)
                    .HasMaxLength(50)
                    .IsFixedLength();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
