﻿using System;
using System.Collections.Generic;

namespace TestLog.Models
{
    public partial class LogItem
    {
        public int Id { get; set; }
        public string? LogMsg { get; set; }
    }
}
