using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using TestLog.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//�M��޲z�D���x��J���O:Scaffold-DbContext "Server=���A����m;Database=��Ʈw;Trusted_Connection=True;User ID=�b��;Password=�K�X" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Force

builder.Services.AddDbContext<TestLogContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("TestLogDatabase")));



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
